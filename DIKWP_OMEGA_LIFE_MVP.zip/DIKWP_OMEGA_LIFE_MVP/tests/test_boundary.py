from pathlib import Path

from omega_life.boundary import rank_boundaries
from omega_life.utils import load_json


def test_cell_core_is_best_boundary_candidate():
    root = Path(__file__).resolve().parents[1]
    data = load_json(root / "data" / "boundary_example.json")
    ranked = rank_boundaries(data["candidates"], data["interactions"], data["gating"])
    assert ranked[0].candidate_name == "细胞核心"
    assert ranked[0].score > ranked[-1].score
