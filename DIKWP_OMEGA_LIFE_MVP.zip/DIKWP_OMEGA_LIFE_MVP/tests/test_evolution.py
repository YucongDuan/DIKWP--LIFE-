from pathlib import Path

import networkx as nx

from omega_life.cli import _load_entities, _seed_world


def test_simulation_runs_and_lineage_remains_dag():
    root = Path(__file__).resolve().parents[1]
    entities = _load_entities(root / "data" / "seed_entities.json")
    world = _seed_world(entities)
    snapshots, events = world.run(steps=12)
    assert len(snapshots) == 13
    assert snapshots[-1].population >= 1
    assert len(events) >= 1
    assert nx.is_directed_acyclic_graph(world.graph)
