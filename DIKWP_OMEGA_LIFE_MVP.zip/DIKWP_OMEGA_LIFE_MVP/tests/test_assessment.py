from pathlib import Path

from omega_life.assessment import assess_entity
from omega_life.models import EntityProfile
from omega_life.utils import load_json


def load_profiles():
    root = Path(__file__).resolve().parents[1]
    data = load_json(root / "data" / "seed_entities.json")
    return {item["entity_id"]: EntityProfile.from_mapping(item) for item in data["entities"]}


def test_rock_is_not_life():
    result = assess_entity(load_profiles()["rock"])
    assert result.primary_phase == "NONLIVING_OR_DERIVATIVE"
    assert not result.passed_core


def test_bacterium_is_core_adaptive_life():
    result = assess_entity(load_profiles()["bacterium"])
    assert result.primary_phase == "CORE_LIFE"
    assert result.passed_core
    assert "适应性生命" in result.facets
    assert "可演化谱系" in result.facets


def test_single_llm_session_is_not_life():
    result = assess_entity(load_profiles()["llm_session"])
    assert not result.passed_core
    assert result.core_gate < 0.20


def test_autonomous_digital_candidate_crosses_life_gate():
    result = assess_entity(load_profiles()["autonomous_digital_life"])
    assert result.primary_phase == "CORE_LIFE"
    assert "元演化生命" in result.facets
    assert "跨基质生命" in result.facets
    assert result.welfare_review["review_required"]


def test_virus_is_derivative_replicator():
    result = assess_entity(load_profiles()["virus_extracellular"])
    assert not result.passed_core
    assert "生命衍生型复制者" in result.facets


def test_dormant_spore_is_life_despite_low_current_flux():
    result = assess_entity(load_profiles()["dormant_spore"])
    assert result.primary_phase == "DORMANT_LIFE"
    assert result.passed_core
