from __future__ import annotations

from typing import Dict, Iterable, List, Mapping

from .consciousness import assess_welfare_relevance
from .models import AssessmentResult, EntityProfile
from .utils import clamp, geometric_mean

DIMENSION_NAMES_ZH: Dict[str, str] = {
    "ENR": "非平衡通量",
    "BND": "选择性边界",
    "AUT": "因果自主性",
    "CON": "约束闭包/自生产",
    "REG": "可生存域调节",
    "REP": "修复与再生",
    "IDN": "身份连续性",
    "MEM": "历史记忆",
    "SEN": "状态感知",
    "AGY": "内生能动性",
    "LRN": "学习适应",
    "MOD": "规则自修改",
    "HER": "延续与遗传",
    "VAR": "变异与多样性",
    "OEE": "开放式演化",
    "MSC": "多尺度整合",
    "ECO": "生态互构",
    "XSB": "跨基质迁移",
}

CORE_DIMS = ["ENR", "BND", "CON", "REG", "IDN"]
ADAPTIVE_DIMS = ["MEM", "SEN", "AGY", "LRN"]
EVOLUTION_DIMS = ["HER", "VAR"]
META_DIMS = ["MOD", "OEE"]
COLLECTIVE_DIMS = ["MSC", "ECO"]
ALL_DIMS = list(DIMENSION_NAMES_ZH)

PHASE_ZH = {
    "NONLIVING_OR_DERIVATIVE": "非生命或生命衍生物",
    "DISSIPATIVE_ORDER": "耗散有序结构",
    "PROTO_LIFE": "原生命/临界生命",
    "DORMANT_LIFE": "休眠生命",
    "CORE_LIFE": "核心生命",
}


def _lower_bounds(scores: Mapping[str, float], confidence: float) -> Dict[str, float]:
    penalty = (1.0 - clamp(confidence)) * 0.24
    return {key: clamp(float(scores.get(key, 0.0)) - penalty) for key in ALL_DIMS}


def _band(confidence: float, distance: float) -> str:
    certainty = 0.65 * clamp(confidence) + 0.35 * clamp(distance / 0.35)
    if certainty >= 0.78:
        return "高"
    if certainty >= 0.58:
        return "中"
    return "低"


def assess_entity(entity: EntityProfile) -> AssessmentResult:
    scores = {key: clamp(entity.dimensions.get(key, 0.0)) for key in ALL_DIMS}
    lower = _lower_bounds(scores, entity.confidence)

    core_gate = min(lower[key] for key in CORE_DIMS)
    adaptive_gate = min(lower[key] for key in ADAPTIVE_DIMS)
    evolution_gate = min(lower[key] for key in EVOLUTION_DIMS)
    meta_gate = min(lower[key] for key in META_DIMS)
    collective_gate = min(lower[key] for key in COLLECTIVE_DIMS)
    life_richness = geometric_mean([scores[k] for k in CORE_DIMS + ADAPTIVE_DIMS + META_DIMS])

    dormant = entity.state_mode == "dormant" and (entity.latent_core_score or 0.0) >= 0.55
    passed_core = core_gate >= 0.55 or dormant
    failed = [DIMENSION_NAMES_ZH[k] for k in CORE_DIMS if lower[k] < 0.55]

    if dormant:
        phase = "DORMANT_LIFE"
    elif core_gate >= 0.55:
        phase = "CORE_LIFE"
    else:
        partial_mean = sum(lower[k] for k in CORE_DIMS) / len(CORE_DIMS)
        partial_count = sum(lower[k] >= 0.35 for k in CORE_DIMS)
        if partial_mean >= 0.32 and partial_count >= 3:
            phase = "PROTO_LIFE"
        elif lower["ENR"] >= 0.52:
            phase = "DISSIPATIVE_ORDER"
        else:
            phase = "NONLIVING_OR_DERIVATIVE"

    facets: List[str] = []
    reasoning: List[str] = []
    if passed_core:
        facets.append("递归可生存闭包")
        reasoning.append("核心门满足：通量、边界、约束自生产、可生存调节和身份连续形成联动。")
    else:
        reasoning.append("核心门未满足；单一的复杂性、复制、耗散或信息处理不足以构成生命。")

    if passed_core and adaptive_gate >= 0.42:
        facets.append("适应性生命")
        reasoning.append("历史记忆、状态辨别、内生行动和学习均超过适应门槛。")
    if lower["HER"] >= 0.55 and lower["VAR"] >= 0.45:
        if passed_core:
            facets.append("可演化谱系")
        else:
            facets.append("生命衍生型复制者")
            reasoning.append("具有遗传与变异，但缺少当前尺度上的自主可生存闭包。")
    if passed_core and meta_gate >= 0.52:
        facets.append("元演化生命")
        reasoning.append("系统能够修改自身适应规则并扩展可达状态空间。")
    if collective_gate >= 0.52 and lower["MSC"] >= 0.55:
        facets.append("多尺度集体个体")
    if passed_core and lower["XSB"] >= 0.65:
        facets.append("跨基质生命")
    if lower["AUT"] < 0.40 and (passed_core or "生命衍生型复制者" in facets):
        facets.append("宿主依赖")
    if entity.state_mode == "dormant":
        facets.append("可逆休眠")
        reasoning.append("当前低通量不等于死亡；潜在闭包、身份与可再激活证据支持休眠判定。")

    if phase == "DISSIPATIVE_ORDER":
        reasoning.append("存在显著能量耗散和结构维持，但约束闭包、内生规范与历史适应不足。")
    elif phase == "PROTO_LIFE":
        reasoning.append("若干生命机制已出现，但尚未形成稳健的递归可生存闭包。")
    elif phase == "NONLIVING_OR_DERIVATIVE":
        reasoning.append("当前证据更符合被动对象、工具、复制模板或生命制造的衍生结构。")

    welfare = assess_welfare_relevance(entity.consciousness, entity.confidence)
    if welfare["review_required"]:
        facets.append("福利复核触发")
        reasoning.append("生命与意识分开判定；意识候选指标触发预防性福利复核，但不构成现象体验证明。")

    threshold_reference = 0.55 if phase in {"CORE_LIFE", "DORMANT_LIFE"} else 0.32
    distance = abs(core_gate - threshold_reference)

    return AssessmentResult(
        entity_id=entity.entity_id,
        name_zh=entity.name_zh,
        primary_phase=phase,
        phase_zh=PHASE_ZH[phase],
        facets=facets,
        core_gate=round(core_gate, 4),
        adaptive_gate=round(adaptive_gate, 4),
        evolution_gate=round(evolution_gate, 4),
        meta_gate=round(meta_gate, 4),
        collective_gate=round(collective_gate, 4),
        life_richness=round(life_richness, 4),
        autonomy=round(lower["AUT"], 4),
        confidence=round(entity.confidence, 4),
        certainty_band=_band(entity.confidence, distance),
        passed_core=passed_core,
        failed_core_dimensions=failed,
        lower_bounds={k: round(v, 4) for k, v in lower.items()},
        dimension_scores={k: round(v, 4) for k, v in scores.items()},
        welfare_review=welfare,
        reasoning=reasoning,
    )


def assess_entities(entities: Iterable[EntityProfile]) -> List[AssessmentResult]:
    return [assess_entity(entity) for entity in entities]
