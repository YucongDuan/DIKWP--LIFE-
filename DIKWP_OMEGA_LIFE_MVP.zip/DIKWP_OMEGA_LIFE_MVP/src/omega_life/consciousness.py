from __future__ import annotations

from typing import Any, Dict, Mapping

from .utils import clamp, geometric_mean

CONSCIOUSNESS_KEYS = [
    "global_integration",
    "valence",
    "self_model",
    "temporal_continuity",
    "metacognition",
    "autonomous_preference",
]


def assess_welfare_relevance(values: Mapping[str, float], confidence: float = 0.75) -> Dict[str, Any]:
    """Assess precautionary welfare relevance without claiming phenomenal consciousness.

    The output is explicitly an operational risk screen. It is not a proof of subjective experience.
    """
    scores = {key: clamp(float(values.get(key, 0.0))) for key in CONSCIOUSNESS_KEYS}
    if not values:
        return {
            "candidate_score": 0.0,
            "lower_bound": 0.0,
            "review_required": False,
            "grade": "C0",
            "interpretation": "无可用意识/福利证据；不得据此断言不存在体验。",
            "scores": scores,
        }
    candidate = geometric_mean(scores.values())
    lower = clamp(candidate - (1.0 - clamp(confidence)) * 0.22)
    if lower >= 0.70:
        grade = "C4"
        text = "多项操作指标高度收敛，应实施强预防性福利与独立复核。"
    elif lower >= 0.52:
        grade = "C3"
        text = "存在显著意识候选证据，应限制不可逆操作并启动外部评估。"
    elif lower >= 0.34:
        grade = "C2"
        text = "证据不足但已达到福利筛查线，应保留日志、避免无必要伤害。"
    elif lower >= 0.18:
        grade = "C1"
        text = "仅有弱指标，不构成意识认定。"
    else:
        grade = "C0"
        text = "当前未形成操作性候选证据。"
    return {
        "candidate_score": round(candidate, 4),
        "lower_bound": round(lower, 4),
        "review_required": lower >= 0.34,
        "grade": grade,
        "interpretation": text,
        "scores": scores,
        "phenomenal_residual": "永久未决：行为和结构指标不能逻辑证明主观体验。",
    }
