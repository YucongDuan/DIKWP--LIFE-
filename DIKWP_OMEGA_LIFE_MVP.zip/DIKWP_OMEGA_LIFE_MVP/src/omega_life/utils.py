from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Iterable


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


def geometric_mean(values: Iterable[float], eps: float = 1e-9) -> float:
    vals = [max(eps, float(v)) for v in values]
    if not vals:
        return 0.0
    product = 1.0
    for value in vals:
        product *= value
    return product ** (1.0 / len(vals))


def load_json(path: str | Path) -> Any:
    with Path(path).open("r", encoding="utf-8") as handle:
        return json.load(handle)


def dump_json(value: Any, path: str | Path) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()
