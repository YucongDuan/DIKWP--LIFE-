from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Tuple
import math
import random
import uuid

import networkx as nx
import numpy as np

from .assessment import ALL_DIMS, assess_entity
from .models import EntityProfile, LineageEvent
from .utils import clamp


@dataclass
class SimEntity:
    entity_id: str
    name: str
    substrate: str
    dimensions: Dict[str, float]
    reserve: float = 0.65
    generation: int = 0
    parents: List[str] = field(default_factory=list)
    alive: bool = True
    state_mode: str = "active"

    def profile(self) -> EntityProfile:
        return EntityProfile(
            entity_id=self.entity_id,
            name_zh=self.name,
            name_en=self.name,
            substrate=self.substrate,
            scale="simulation",
            dimensions=self.dimensions,
            confidence=0.72,
            state_mode=self.state_mode,
            latent_core_score=0.65 if self.state_mode == "dormant" else None,
        )


@dataclass
class SimulationSnapshot:
    step: int
    population: int
    by_substrate: Dict[str, int]
    mean_core_gate: float
    trait_volume: float
    novelty: float

    def to_dict(self) -> Dict[str, Any]:
        return {
            "step": self.step,
            "population": self.population,
            "by_substrate": self.by_substrate,
            "mean_core_gate": round(self.mean_core_gate, 4),
            "trait_volume": round(self.trait_volume, 4),
            "novelty": round(self.novelty, 4),
        }


class EvolutionWorld:
    """Demonstration world with co-evolving entities and changing rules.

    This is not a biological forecast. It operationalizes fork, merge, symbiosis,
    rule modification and substrate migration so that evolution is not limited to
    a fixed genotype/fitness landscape.
    """

    def __init__(self, seed: int = 19, population_cap: int = 90) -> None:
        self.rng = random.Random(seed)
        self.population_cap = population_cap
        self.entities: Dict[str, SimEntity] = {}
        self.events: List[LineageEvent] = []
        self.graph = nx.DiGraph()
        self.resources: Dict[str, float] = {
            "biochemical": 0.75,
            "digital": 0.70,
            "robotic": 0.55,
            "hybrid": 0.62,
            "collective": 0.68,
        }
        self.initial_trait_centroid: np.ndarray | None = None

    def add_entity(self, entity: SimEntity) -> None:
        self.entities[entity.entity_id] = entity
        self.graph.add_node(entity.entity_id, generation=entity.generation, substrate=entity.substrate)

    def _new_id(self, prefix: str) -> str:
        return f"{prefix}-{uuid.uuid4().hex[:8]}"

    def _record(self, step: int, event_type: str, parents: List[str], children: List[str], **details: Any) -> None:
        event = LineageEvent(
            event_id=f"EV-{step:03d}-{len(self.events)+1:04d}",
            step=step,
            event_type=event_type,
            parents=parents,
            children=children,
            details=details,
        )
        self.events.append(event)
        for child in children:
            self.graph.add_node(child)
            for parent in parents:
                self.graph.add_edge(parent, child, event_type=event_type, step=step)

    def _mutate_dimensions(self, parent: SimEntity) -> Dict[str, float]:
        dims = dict(parent.dimensions)
        variation = dims.get("VAR", 0.25)
        modifier = dims.get("MOD", 0.15)
        for key in ALL_DIMS:
            if self.rng.random() < 0.30 + 0.25 * modifier:
                sigma = 0.018 + 0.075 * variation
                dims[key] = clamp(dims.get(key, 0.0) + self.rng.gauss(0.0, sigma))
        # Meta-dynamics can change which dimensions receive investment.
        if self.rng.random() < modifier * 0.22:
            target = self.rng.choice(ALL_DIMS)
            dims[target] = clamp(dims[target] + self.rng.uniform(0.04, 0.12))
        return dims

    def _reproduce(self, entity: SimEntity, step: int) -> None:
        child_id = self._new_id(entity.substrate[:3])
        child = SimEntity(
            entity_id=child_id,
            name=f"{entity.name}后继{entity.generation+1}",
            substrate=entity.substrate,
            dimensions=self._mutate_dimensions(entity),
            reserve=0.48,
            generation=entity.generation + 1,
            parents=[entity.entity_id],
        )
        entity.reserve -= 0.24
        self.add_entity(child)
        self._record(step, "continuation", [entity.entity_id], [child_id], mode="reproduction_or_copy")

    def _fork(self, entity: SimEntity, step: int) -> None:
        children = []
        for branch in ("A", "B"):
            child_id = self._new_id("fork")
            dims = self._mutate_dimensions(entity)
            dims["IDN"] = clamp(dims.get("IDN", 0.5) - 0.04)
            child = SimEntity(
                entity_id=child_id,
                name=f"{entity.name}分叉{branch}",
                substrate=entity.substrate,
                dimensions=dims,
                reserve=0.44,
                generation=entity.generation + 1,
                parents=[entity.entity_id],
            )
            self.add_entity(child)
            children.append(child_id)
        entity.reserve -= 0.30
        self._record(step, "fork", [entity.entity_id], children, identity_policy="branching")

    def _symbiosis(self, a: SimEntity, b: SimEntity, step: int) -> None:
        child_id = self._new_id("sym")
        dims = {}
        for key in ALL_DIMS:
            dims[key] = clamp(0.48 * a.dimensions.get(key, 0.0) + 0.48 * b.dimensions.get(key, 0.0) + 0.04)
        dims["ECO"] = clamp(max(a.dimensions.get("ECO", 0), b.dimensions.get("ECO", 0)) + 0.08)
        dims["MSC"] = clamp(max(a.dimensions.get("MSC", 0), b.dimensions.get("MSC", 0)) + 0.06)
        substrate = "hybrid" if a.substrate != b.substrate else a.substrate
        child = SimEntity(
            entity_id=child_id,
            name=f"{a.name}+{b.name}共生体",
            substrate=substrate,
            dimensions=dims,
            reserve=0.58,
            generation=max(a.generation, b.generation) + 1,
            parents=[a.entity_id, b.entity_id],
        )
        a.reserve -= 0.12
        b.reserve -= 0.12
        self.add_entity(child)
        self._record(step, "symbiosis_merge", [a.entity_id, b.entity_id], [child_id])

    def _migrate(self, entity: SimEntity, step: int) -> None:
        target = max(self.resources, key=self.resources.get)
        if target == entity.substrate:
            return
        old = entity.substrate
        entity.substrate = target
        entity.reserve -= 0.08
        entity.dimensions["XSB"] = clamp(entity.dimensions.get("XSB", 0.0) + 0.02)
        self._record(step, "substrate_migration", [entity.entity_id], [entity.entity_id], old=old, new=target)

    def _update_environment(self, step: int) -> None:
        for substrate in self.resources:
            recharge = 0.035 + 0.015 * math.sin((step + len(substrate)) / 4.0)
            shock = 0.0
            if self.rng.random() < 0.08:
                shock = self.rng.uniform(0.08, 0.24)
            usage = sum(
                0.006 + 0.010 * e.dimensions.get("ENR", 0.0)
                for e in self.entities.values()
                if e.alive and e.substrate == substrate
            )
            eco_return = sum(
                0.0025 * e.dimensions.get("ECO", 0.0)
                for e in self.entities.values()
                if e.alive and e.substrate == substrate
            )
            self.resources[substrate] = clamp(self.resources[substrate] + recharge + eco_return - usage - shock, 0.05, 1.0)

    def _step_entity(self, entity: SimEntity, step: int) -> None:
        if not entity.alive:
            return
        assessment = assess_entity(entity.profile())
        resource = self.resources.get(entity.substrate, 0.5)
        intake = resource * (0.16 + 0.34 * entity.dimensions.get("ENR", 0.0)) * (
            0.72 + 0.28 * entity.dimensions.get("AGY", 0.0)
        )
        complexity_cost = 0.10 + 0.08 * np.mean(list(entity.dimensions.values()))
        maintenance_efficiency = 0.45 * entity.dimensions.get("REG", 0.0) + 0.25 * entity.dimensions.get("CON", 0.0)
        entity.reserve = clamp(entity.reserve + intake - complexity_cost + 0.06 * maintenance_efficiency, 0.0, 1.2)

        stress = max(0.0, 0.48 - entity.reserve)
        if stress > 0 and self.rng.random() < entity.dimensions.get("LRN", 0.0) * 0.50:
            for key in self.rng.sample(["REG", "SEN", "AGY", "ENR", "REP"], k=2):
                entity.dimensions[key] = clamp(entity.dimensions.get(key, 0.0) + 0.02 + 0.05 * stress)
            self._record(step, "within_lifetime_learning", [entity.entity_id], [entity.entity_id], stress=round(stress, 3))

        if entity.reserve < 0.13:
            if entity.dimensions.get("REP", 0.0) >= 0.58 and self.rng.random() < 0.45:
                entity.reserve = 0.28
                entity.dimensions["REP"] = clamp(entity.dimensions.get("REP", 0.0) + 0.01)
                self._record(step, "repair", [entity.entity_id], [entity.entity_id])
            elif entity.dimensions.get("IDN", 0.0) >= 0.72 and self.rng.random() < 0.35:
                entity.state_mode = "dormant"
                entity.reserve = 0.18
                self._record(step, "dormancy", [entity.entity_id], [entity.entity_id])
            else:
                entity.alive = False
                self._record(step, "termination", [entity.entity_id], [], reason="viability_loss")
                return

        if entity.state_mode == "dormant" and resource > 0.66 and self.rng.random() < 0.25:
            entity.state_mode = "active"
            entity.reserve = 0.36
            self._record(step, "reactivation", [entity.entity_id], [entity.entity_id])

        if len([e for e in self.entities.values() if e.alive]) < self.population_cap:
            heredity = entity.dimensions.get("HER", 0.0)
            if entity.reserve > 0.82 and self.rng.random() < heredity * 0.20:
                if entity.substrate in {"digital", "hybrid"} and entity.dimensions.get("XSB", 0.0) > 0.64 and self.rng.random() < 0.32:
                    self._fork(entity, step)
                else:
                    self._reproduce(entity, step)

        if entity.dimensions.get("XSB", 0.0) > 0.68 and resource < 0.35 and self.rng.random() < 0.22:
            self._migrate(entity, step)

    def _maybe_symbiosis(self, step: int) -> None:
        alive = [e for e in self.entities.values() if e.alive and e.reserve > 0.55]
        self.rng.shuffle(alive)
        for i in range(0, len(alive) - 1, 2):
            a, b = alive[i], alive[i + 1]
            probability = 0.06 * min(a.dimensions.get("ECO", 0.0), b.dimensions.get("ECO", 0.0))
            if len([e for e in self.entities.values() if e.alive]) < self.population_cap and self.rng.random() < probability:
                self._symbiosis(a, b, step)
                break

    def _trait_volume(self, alive: List[SimEntity]) -> float:
        if len(alive) < 3:
            return 0.0
        matrix = np.array([[e.dimensions.get(k, 0.0) for k in ALL_DIMS] for e in alive])
        cov = np.cov(matrix, rowvar=False)
        eigvals = np.linalg.eigvalsh(cov)
        return float(np.sum(np.sqrt(np.clip(eigvals, 0.0, None))))

    def _novelty(self, alive: List[SimEntity]) -> float:
        if not alive:
            return 0.0
        matrix = np.array([[e.dimensions.get(k, 0.0) for k in ALL_DIMS] for e in alive])
        centroid = matrix.mean(axis=0)
        if self.initial_trait_centroid is None:
            self.initial_trait_centroid = centroid.copy()
        return float(np.linalg.norm(centroid - self.initial_trait_centroid) / math.sqrt(len(ALL_DIMS)))

    def snapshot(self, step: int) -> SimulationSnapshot:
        alive = [e for e in self.entities.values() if e.alive]
        by_substrate: Dict[str, int] = {}
        gates = []
        for entity in alive:
            by_substrate[entity.substrate] = by_substrate.get(entity.substrate, 0) + 1
            gates.append(assess_entity(entity.profile()).core_gate)
        return SimulationSnapshot(
            step=step,
            population=len(alive),
            by_substrate=by_substrate,
            mean_core_gate=float(np.mean(gates)) if gates else 0.0,
            trait_volume=self._trait_volume(alive),
            novelty=self._novelty(alive),
        )

    def run(self, steps: int = 36) -> Tuple[List[SimulationSnapshot], List[LineageEvent]]:
        snapshots = [self.snapshot(0)]
        for step in range(1, steps + 1):
            self._update_environment(step)
            current = list(self.entities.values())
            for entity in current:
                self._step_entity(entity, step)
            self._maybe_symbiosis(step)
            snapshots.append(self.snapshot(step))
        if not nx.is_directed_acyclic_graph(self.graph):
            # Self-loop events such as repair/migration are intentionally not lineage edges.
            self.graph.remove_edges_from(nx.selfloop_edges(self.graph))
        return snapshots, self.events
