from __future__ import annotations

from typing import Dict, Iterable, List, Mapping, Sequence

import networkx as nx

from .models import BoundaryAssessment
from .utils import clamp


def assess_boundary_candidate(
    candidate_name: str,
    members: Sequence[str],
    interactions: Mapping[str, Mapping[str, float]],
    gating: Mapping[str, float] | None = None,
) -> BoundaryAssessment:
    member_set = set(members)
    nodes = set(interactions)
    for targets in interactions.values():
        nodes.update(targets)

    internal = 0.0
    cross = 0.0
    graph = nx.DiGraph()
    graph.add_nodes_from(members)
    for source, targets in interactions.items():
        for target, weight_raw in targets.items():
            weight = max(0.0, float(weight_raw))
            if source in member_set and target in member_set:
                internal += weight
                if weight > 0:
                    graph.add_edge(source, target, weight=weight)
            elif (source in member_set) ^ (target in member_set):
                cross += weight

    cohesion = internal / (internal + cross + 1e-9)
    if len(members) <= 1:
        cycle_fraction = 0.0
    else:
        sccs = [component for component in nx.strongly_connected_components(graph) if len(component) > 1]
        covered = len(set().union(*sccs)) if sccs else 0
        cycle_fraction = covered / len(members)

    gating_values: List[float] = []
    if gating:
        for node in members:
            if node in gating:
                gating_values.append(clamp(float(gating[node])))
    selectivity = sum(gating_values) / len(gating_values) if gating_values else 0.25

    # A useful boundary must both cohere internally and face a non-empty outside.
    # Treating the entire modeled universe as the candidate would otherwise score trivially well.
    interface_evidence = clamp(cross / 0.8)
    score = clamp(0.40 * cohesion + 0.30 * cycle_fraction + 0.20 * selectivity + 0.10 * interface_evidence)
    explanation = (
        f"内部因果凝聚度{cohesion:.2f}，闭环覆盖{cycle_fraction:.2f}，"
        f"边界选择性{selectivity:.2f}，外部界面证据{interface_evidence:.2f}。"
        "该分数只用于提出尺度候选，不把观察者选择误装成绝对边界。"
    )
    return BoundaryAssessment(
        candidate_name=candidate_name,
        members=list(members),
        cohesion=round(cohesion, 4),
        cycle_fraction=round(cycle_fraction, 4),
        selectivity=round(selectivity, 4),
        score=round(score, 4),
        explanation=explanation,
    )


def rank_boundaries(
    candidates: Mapping[str, Sequence[str]],
    interactions: Mapping[str, Mapping[str, float]],
    gating: Mapping[str, float] | None = None,
) -> List[BoundaryAssessment]:
    values = [
        assess_boundary_candidate(name, members, interactions, gating)
        for name, members in candidates.items()
    ]
    return sorted(values, key=lambda item: item.score, reverse=True)
