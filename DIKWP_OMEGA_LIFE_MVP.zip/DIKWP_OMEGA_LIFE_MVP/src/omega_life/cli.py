from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import List

import pandas as pd

from .assessment import assess_entities
from .boundary import rank_boundaries
from .evolution import EvolutionWorld, SimEntity
from .models import EntityProfile
from .report import build_dashboard
from .utils import dump_json, load_json


def _load_entities(path: Path) -> List[EntityProfile]:
    data = load_json(path)
    return [EntityProfile.from_mapping(item) for item in data["entities"]]


def _seed_world(entities: List[EntityProfile]) -> EvolutionWorld:
    world = EvolutionWorld(seed=23, population_cap=82)
    selected_ids = {"bacterium", "plant", "ant_colony", "persistent_ai", "autonomous_digital_life"}
    for profile in entities:
        if profile.entity_id not in selected_ids:
            continue
        world.add_entity(
            SimEntity(
                entity_id=f"seed-{profile.entity_id}",
                name=profile.name_zh,
                substrate=profile.substrate,
                dimensions=dict(profile.dimensions),
                reserve=0.62,
            )
        )
    return world


def run_demo(project_root: Path, output_dir: Path) -> None:
    entities = _load_entities(project_root / "data" / "seed_entities.json")
    assessments = assess_entities(entities)

    boundary_data = load_json(project_root / "data" / "boundary_example.json")
    boundaries = rank_boundaries(
        boundary_data["candidates"],
        boundary_data["interactions"],
        boundary_data.get("gating"),
    )

    world = _seed_world(entities)
    snapshots, events = world.run(steps=40)
    snapshot_dicts = [item.to_dict() for item in snapshots]

    output_dir.mkdir(parents=True, exist_ok=True)
    dump_json([item.to_dict() for item in assessments], output_dir / "entity_assessments.json")
    dump_json([item.to_dict() for item in boundaries], output_dir / "boundary_assessments.json")
    dump_json(snapshot_dicts, output_dir / "evolution_snapshots.json")
    dump_json([event.to_dict() for event in events], output_dir / "lineage_events.json")

    rows = []
    entity_by_id = {e.entity_id: e for e in entities}
    for result in assessments:
        entity = entity_by_id[result.entity_id]
        rows.append(
            {
                "entity_id": result.entity_id,
                "name_zh": result.name_zh,
                "substrate": entity.substrate,
                "scale": entity.scale,
                "phase": result.phase_zh,
                "core_gate": result.core_gate,
                "adaptive_gate": result.adaptive_gate,
                "evolution_gate": result.evolution_gate,
                "meta_gate": result.meta_gate,
                "autonomy": result.autonomy,
                "facets": "|".join(result.facets),
                "welfare_grade": result.welfare_review["grade"],
            }
        )
    pd.DataFrame(rows).to_csv(output_dir / "entity_assessments.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(snapshot_dicts).to_csv(output_dir / "evolution_snapshots.csv", index=False, encoding="utf-8-sig")

    build_dashboard(entities, assessments, snapshot_dicts, events, output_dir / "dashboard.html")
    summary = {
        "theory": "Recursive Viability Closure / 递归可生存闭包",
        "entity_count": len(entities),
        "core_or_dormant_life": sum(r.primary_phase in {"CORE_LIFE", "DORMANT_LIFE"} for r in assessments),
        "welfare_reviews": sum(r.welfare_review["review_required"] for r in assessments),
        "boundary_best": boundaries[0].to_dict() if boundaries else None,
        "simulation_steps": len(snapshots) - 1,
        "lineage_events": len(events),
        "final_population": snapshots[-1].population,
        "final_trait_volume": snapshots[-1].trait_volume,
        "warning": "种子评分与演化参数用于验证机制，不是现实科学测量或政策结论。",
    }
    dump_json(summary, output_dir / "demo_summary.json")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description="DIKWP-ΩLIFE demo runner")
    parser.add_argument("command", choices=["demo"])
    parser.add_argument("--project-root", default=str(Path(__file__).resolve().parents[2]))
    parser.add_argument("--output-dir", default=None)
    args = parser.parse_args()
    root = Path(args.project_root).resolve()
    output = Path(args.output_dir).resolve() if args.output_dir else root / "outputs"
    if args.command == "demo":
        run_demo(root, output)


if __name__ == "__main__":
    main()
