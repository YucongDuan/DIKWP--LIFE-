from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Mapping, Optional


@dataclass
class EntityProfile:
    entity_id: str
    name_zh: str
    name_en: str
    substrate: str
    scale: str
    dimensions: Dict[str, float]
    confidence: float = 0.75
    state_mode: str = "active"
    latent_core_score: Optional[float] = None
    consciousness: Dict[str, float] = field(default_factory=dict)
    evidence_notes: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "EntityProfile":
        return cls(
            entity_id=str(value["entity_id"]),
            name_zh=str(value.get("name_zh", value["entity_id"])),
            name_en=str(value.get("name_en", value["entity_id"])),
            substrate=str(value.get("substrate", "unknown")),
            scale=str(value.get("scale", "unspecified")),
            dimensions={k: float(v) for k, v in value.get("dimensions", {}).items()},
            confidence=float(value.get("confidence", 0.75)),
            state_mode=str(value.get("state_mode", "active")),
            latent_core_score=(
                None if value.get("latent_core_score") is None else float(value["latent_core_score"])
            ),
            consciousness={k: float(v) for k, v in value.get("consciousness", {}).items()},
            evidence_notes=list(value.get("evidence_notes", [])),
            metadata=dict(value.get("metadata", {})),
        )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class AssessmentResult:
    entity_id: str
    name_zh: str
    primary_phase: str
    phase_zh: str
    facets: List[str]
    core_gate: float
    adaptive_gate: float
    evolution_gate: float
    meta_gate: float
    collective_gate: float
    life_richness: float
    autonomy: float
    confidence: float
    certainty_band: str
    passed_core: bool
    failed_core_dimensions: List[str]
    lower_bounds: Dict[str, float]
    dimension_scores: Dict[str, float]
    welfare_review: Dict[str, Any]
    reasoning: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class BoundaryAssessment:
    candidate_name: str
    members: List[str]
    cohesion: float
    cycle_fraction: float
    selectivity: float
    score: float
    explanation: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class LineageEvent:
    event_id: str
    step: int
    event_type: str
    parents: List[str]
    children: List[str]
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
