from __future__ import annotations

import base64
import io
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List

import matplotlib.pyplot as plt
from matplotlib import font_manager
import networkx as nx
import numpy as np
import pandas as pd
from jinja2 import Template
from sklearn.decomposition import PCA

from .assessment import ALL_DIMS, DIMENSION_NAMES_ZH
from .models import AssessmentResult, EntityProfile, LineageEvent


def _set_cjk_font() -> None:
    candidates = [
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc",
        "/usr/share/fonts/truetype/arphic/gbsn00lp.ttf",
    ]
    for path in candidates:
        if Path(path).exists():
            font_manager.fontManager.addfont(path)
            prop = font_manager.FontProperties(fname=path)
            plt.rcParams["font.family"] = prop.get_name()
            break
    plt.rcParams["axes.unicode_minus"] = False


def _fig_to_b64(fig: plt.Figure) -> str:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=160, bbox_inches="tight")
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def morphospace_figure(entities: List[EntityProfile], assessments: List[AssessmentResult]) -> str:
    _set_cjk_font()
    matrix = np.array([[e.dimensions.get(k, 0.0) for k in ALL_DIMS] for e in entities])
    coords = PCA(n_components=2).fit_transform(matrix)
    fig, ax = plt.subplots(figsize=(8.4, 5.6))
    phases = [a.phase_zh for a in assessments]
    unique = sorted(set(phases))
    for phase in unique:
        idx = [i for i, value in enumerate(phases) if value == phase]
        ax.scatter(coords[idx, 0], coords[idx, 1], s=70, label=phase, alpha=0.8)
    for i, entity in enumerate(entities):
        ax.annotate(entity.name_zh, (coords[i, 0], coords[i, 1]), xytext=(4, 3), textcoords="offset points", fontsize=8)
    ax.set_title("18维生命形态空间的二维投影（PCA，仅作展示）")
    ax.set_xlabel("主成分1")
    ax.set_ylabel("主成分2")
    ax.legend(fontsize=8, loc="best")
    ax.grid(alpha=0.2)
    return _fig_to_b64(fig)


def heatmap_figure(entities: List[EntityProfile]) -> str:
    _set_cjk_font()
    names = [e.name_zh for e in entities]
    matrix = np.array([[e.dimensions.get(k, 0.0) for k in ALL_DIMS] for e in entities])
    fig, ax = plt.subplots(figsize=(11.2, 7.4))
    image = ax.imshow(matrix, aspect="auto", vmin=0, vmax=1)
    ax.set_yticks(range(len(names)))
    ax.set_yticklabels(names, fontsize=8)
    ax.set_xticks(range(len(ALL_DIMS)))
    ax.set_xticklabels([DIMENSION_NAMES_ZH[k] for k in ALL_DIMS], rotation=55, ha="right", fontsize=8)
    ax.set_title("跨基质候选系统的18维生命向量")
    fig.colorbar(image, ax=ax, fraction=0.025, pad=0.02)
    return _fig_to_b64(fig)


def simulation_figure(snapshots: Iterable[Dict[str, Any]]) -> str:
    _set_cjk_font()
    frame = pd.DataFrame(list(snapshots))
    fig, ax = plt.subplots(figsize=(8.4, 4.8))
    ax.plot(frame["step"], frame["population"], marker="o", markersize=2.5, label="存续实体数")
    ax.plot(frame["step"], frame["mean_core_gate"] * 20, label="平均核心门×20")
    ax.plot(frame["step"], frame["novelty"] * 40, label="新颖度×40")
    ax.set_title("开放演化演示：数量、核心闭包与新颖度")
    ax.set_xlabel("演化步")
    ax.set_ylabel("归一化展示尺度")
    ax.legend(fontsize=8)
    ax.grid(alpha=0.2)
    return _fig_to_b64(fig)


def lineage_figure(events: List[LineageEvent], max_nodes: int = 50) -> str:
    _set_cjk_font()
    graph = nx.DiGraph()
    for event in events:
        if event.event_type not in {"continuation", "fork", "symbiosis_merge"}:
            continue
        for parent in event.parents:
            for child in event.children:
                if parent != child:
                    graph.add_edge(parent, child, event_type=event.event_type)
    if len(graph) > max_nodes:
        graph = graph.subgraph(list(graph.nodes)[:max_nodes]).copy()
    fig, ax = plt.subplots(figsize=(9.2, 6.0))
    if graph.number_of_nodes() == 0:
        ax.text(0.5, 0.5, "无谱系事件", ha="center", va="center")
        ax.axis("off")
        return _fig_to_b64(fig)
    pos = nx.spring_layout(graph, seed=7, k=0.7)
    nx.draw_networkx_nodes(graph, pos, node_size=110, ax=ax)
    nx.draw_networkx_edges(graph, pos, arrows=True, width=0.8, alpha=0.65, ax=ax)
    labels = {node: node.split("-")[0] for node in graph.nodes}
    nx.draw_networkx_labels(graph, pos, labels=labels, font_size=6, ax=ax)
    ax.set_title("生命谱系不是树：复制、分叉与共生合并形成有向无环图")
    ax.axis("off")
    return _fig_to_b64(fig)


DASHBOARD_TEMPLATE = Template(r"""
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>DIKWP-ΩLIFE 离线仪表盘</title>
<style>
:root { --ink:#12253a; --muted:#58697a; --line:#d8e1e9; --panel:#ffffff; --bg:#f4f7fa; --accent:#1f6b8c; }
*{box-sizing:border-box} body{margin:0;background:var(--bg);color:var(--ink);font-family:"Noto Sans CJK SC","Microsoft YaHei",sans-serif;line-height:1.65}
header{padding:34px 6vw;background:linear-gradient(125deg,#102b45,#1f6b8c);color:white}
header h1{margin:0 0 6px;font-size:32px} header p{margin:0;max-width:1000px;opacity:.92}
main{padding:28px 5vw 60px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;margin:18px 0}.card,.panel{background:var(--panel);border:1px solid var(--line);border-radius:14px;box-shadow:0 5px 18px rgba(16,43,69,.06)}
.card{padding:18px}.card .n{font-size:29px;font-weight:700}.card .t{color:var(--muted)}.panel{padding:22px;margin:18px 0}.panel h2{margin-top:0}.panel img{width:100%;height:auto;border-radius:8px;border:1px solid var(--line)}
table{width:100%;border-collapse:collapse;font-size:14px}th,td{border-bottom:1px solid var(--line);padding:9px 8px;text-align:left;vertical-align:top}th{background:#eef4f8;position:sticky;top:0}.tag{display:inline-block;margin:2px 4px 2px 0;padding:2px 8px;border-radius:999px;background:#e8f2f7;color:#164e68;font-size:12px}.warn{background:#fff4df;color:#7a4f00}.mono{font-family:ui-monospace,SFMono-Regular,Consolas,monospace}.small{font-size:13px;color:var(--muted)}
</style>
</head>
<body>
<header>
<h1>DIKWP-ΩLIFE 跨基质高维生命演化系统</h1>
<p>核心理论：生命是在特定尺度上形成“递归可生存闭包”的过程。它不由碳基、细胞、复制或人类相似性单独决定；生命与意识分开评估。</p>
</header>
<main>
<section class="grid">
<div class="card"><div class="n">{{ entity_count }}</div><div class="t">候选系统</div></div>
<div class="card"><div class="n">{{ core_count }}</div><div class="t">核心/休眠生命</div></div>
<div class="card"><div class="n">{{ digital_life_count }}</div><div class="t">数字生命候选</div></div>
<div class="card"><div class="n">{{ welfare_count }}</div><div class="t">福利复核触发</div></div>
<div class="card"><div class="n">{{ event_count }}</div><div class="t">谱系与适应事件</div></div>
</section>
<section class="panel"><h2>最终工作判断</h2><p><strong>生命不是某种材料，而是一种因果组织：</strong>系统通过自身产生的约束，调控能量、物质与信息流，维持内生可生存域；利用历史改变行动，并产生具有身份连续性的后继。可演化生命还会改变产生变异、选择和个体化的规则。</p></section>
<section class="panel"><h2>18维形态空间</h2><img src="data:image/png;base64,{{ morphospace }}" alt="18维生命形态空间二维投影" /></section>
<section class="panel"><h2>维度热图</h2><img src="data:image/png;base64,{{ heatmap }}" alt="生命维度热图" /></section>
<section class="panel"><h2>候选系统判定</h2><div style="overflow:auto;max-height:720px"><table><thead><tr><th>系统</th><th>基质/尺度</th><th>主相位</th><th>核心门</th><th>特征</th><th>意识/福利</th><th>判定理由</th></tr></thead><tbody>
{% for row in rows %}<tr><td><strong>{{ row.name_zh }}</strong><div class="small mono">{{ row.entity_id }}</div></td><td>{{ row.substrate }}<br><span class="small">{{ row.scale }}</span></td><td>{{ row.phase_zh }}<br><span class="small">确定性：{{ row.certainty_band }}</span></td><td>{{ '%.3f'|format(row.core_gate) }}</td><td>{% for tag in row.facets %}<span class="tag">{{ tag }}</span>{% endfor %}</td><td><span class="tag {% if row.welfare_review.review_required %}warn{% endif %}">{{ row.welfare_review.grade }}</span><br><span class="small">{{ row.welfare_review.interpretation }}</span></td><td class="small">{{ row.reasoning|join(' ') }}</td></tr>{% endfor %}
</tbody></table></div></section>
<section class="panel"><h2>开放演化演示</h2><img src="data:image/png;base64,{{ simulation }}" alt="开放演化时间序列" /><p class="small">演示引擎允许复制、分叉、共生合并、休眠、修复、学习和跨基质迁移。结果用于验证系统机制，不是对现实生命演化的数值预测。</p></section>
<section class="panel"><h2>谱系拓扑</h2><img src="data:image/png;base64,{{ lineage }}" alt="谱系有向无环图" /></section>
<section class="panel"><h2>系统边界</h2><p>所有分数都是带不确定性的操作性证据。任何总分都不得覆盖核心闭包短板；意识候选分数不等于主观体验证明；数字程序只有在物理资源、边界、修复、规范和身份闭包实际形成时，才可能成为生命。</p></section>
</main>
</body></html>
""")


def build_dashboard(
    entities: List[EntityProfile],
    assessments: List[AssessmentResult],
    snapshots: List[Dict[str, Any]],
    events: List[LineageEvent],
    output_path: str | Path,
) -> None:
    by_id = {e.entity_id: e for e in entities}
    rows: List[Dict[str, Any]] = []
    for result in assessments:
        entity = by_id[result.entity_id]
        row = result.to_dict()
        row.update({"substrate": entity.substrate, "scale": entity.scale})
        rows.append(row)
    html = DASHBOARD_TEMPLATE.render(
        entity_count=len(entities),
        core_count=sum(r.primary_phase in {"CORE_LIFE", "DORMANT_LIFE"} for r in assessments),
        digital_life_count=sum(
            r.primary_phase in {"CORE_LIFE", "DORMANT_LIFE"} and by_id[r.entity_id].substrate in {"digital", "hybrid"}
            for r in assessments
        ),
        welfare_count=sum(bool(r.welfare_review["review_required"]) for r in assessments),
        event_count=len(events),
        morphospace=morphospace_figure(entities, assessments),
        heatmap=heatmap_figure(entities),
        simulation=simulation_figure(snapshots),
        lineage=lineage_figure(events),
        rows=rows,
    )
    target = Path(output_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(html, encoding="utf-8")
