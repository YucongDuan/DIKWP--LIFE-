"""DIKWP-ΩLIFE: substrate-agnostic high-dimensional life evolution system."""

__version__ = "0.1.0"

from .assessment import assess_entity, assess_entities
from .models import EntityProfile, AssessmentResult

__all__ = ["EntityProfile", "AssessmentResult", "assess_entity", "assess_entities"]
